# New World Grammar Secondary School Website

This is the official website of **New World Grammar Secondary School**, designed for deployment using **GitHub Pages**.

## 📁 Project Structure
- `index.html` – Main homepage
- (Optional) Add folders like `css/`, `images/`, or `js/` as needed

## 🚀 Live Deployment
To deploy via GitHub Pages:
1. Go to **Settings > Pages**
2. Under "Source", select the `main` branch and `root`
3. Save and access your website at:  
   `https://<your-username>.github.io/new-world-school/`

---

© New World Grammar Secondary School, 2025
